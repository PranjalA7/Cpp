#include<iostream>
#include"Functionalities.h"

int main(){

    Container data;
    CreateObjects(data);
    return 0;
}