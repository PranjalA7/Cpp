#ifndef CUSTOMERTYPE_H
#define CUSTOMERTYPE_H

#include<iostream>

enum class CustomerType{
    REGULAR,
    ELITE
};

#endif // CUSTOMERTYPE_H
